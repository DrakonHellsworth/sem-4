// write a java program to perform addition, subtraction, multiplication and division
public class exe1l
{
    public static void main(String args[])
    {
        float a=26;
        float b=88;
        System.out.println("Addition:"+(a+b));
        System.out.println("Subtraction:"+(a-b));
        System.out.println("Multiplication:"+(a*b));
        System.out.println("Division:"+(a/b));
    }
}
//observations:creates a class named exe1l and performs addition, subtraction, multiplication and division using main method and float data type variables a and b for the two numbers and prints the results of the operations.