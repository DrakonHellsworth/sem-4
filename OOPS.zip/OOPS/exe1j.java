// write a java program to check whether a year is a leap year
public class exe1j
{
    public static void main(String args[])
    {
        int year=2026;
        if(year%4==0)
            System.out.println("Leap year");
        else
            System.out.println("Not a leap year");
    }
}
