// write a java program to check whether a year is a leap year
public class exe1j
{
    public static void main(String args[])
    {
        int year=2026;
        if(year%4==0)
            System.out.println("Leap year");
        else
            System.out.println("Not a leap year");
    }
}
//observations:creates a class named exe1j and checks whether a year is a leap year using main method and int data type variable year for the year using modulus operator and if-else statement to determine leap year status and print the result.