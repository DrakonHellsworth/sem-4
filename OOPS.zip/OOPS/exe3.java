// a program to print name
default class exe3
{
    public static void main(String args[])
    {
        System.out.println("My name is Anmol");
    }
}