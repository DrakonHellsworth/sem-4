public class hello // public means it can be accessed from outside the package // class is a keyword to create a type // hello is the name of the class
{
    public static void main(String args[]) // main method - starting point of the program // String args[] is an array of strings to hold command line arguments
    {
        System.out.println("Hello World"); // prints Hello World to the console
    }
}