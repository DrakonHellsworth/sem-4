// write a java program to calculate simple interest
public class exe1d
{
    public static void main(String args[])
    {
        float p=700;
        float t=5;
        float r=4.3f;
        float si=(p*t*r)/100;
        System.out.println("Simple Interest is:"+si);
    }
}
//observations:creates a class named exe1d and prints the simple interest using main method and float data type variables p, t and r for principal, time and rate respectively and si for simple interest variable is created to store the calculated simple interest value. 