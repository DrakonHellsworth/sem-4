// write a java program to calculate simple interest
public class exe1d
{
    public static void main(String args[])
    {
        float p=700f;
        float t=5f;
        float r=4.3f;
        float si=(p*t*r)/100;
        System.out.println("Simple Interest is:"+si);
    }
}
