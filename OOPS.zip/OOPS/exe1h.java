// write a java program to find the largest of two numbers
public class exe1h
{
    public static void main(String args[])
    {
        int a=100;
        int b=999;
        if(a>b)
            System.out.println("Largest number is:"+a);
        else
            System.out.println("Largest number is:"+b);
    }
}
