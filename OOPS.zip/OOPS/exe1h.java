// write a java program to find the largest of two numbers
public class exe1h
{
    public static void main(String args[])
    {
        int a=100;
        int b=999;
        if(a>b)
            System.out.println("Largest number is:"+a);
        else
            System.out.println("Largest number is:"+b);
    }
}
// observations:creates a class named exe1h and finds the largest of two numbers using main method and int data type variables a and b for the two numbers using if-else statement to compare the two numbers.