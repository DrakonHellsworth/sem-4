// write a program to print name,roll number and branch
public class exe1a 
{
    public static void main(String args[])
    {
        System.out.println("Name:Anmol Thapliyal");
        System.out.println("Roll no:590011794");
        System.out.println("Branch: CSE AIML");
    }
}
//observations:creates a class named exe1a and prints the name, roll number and branch of the student.