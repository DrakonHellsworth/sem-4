// write a java program to declare two integers and print their sum
public class exe1b
{
    public static void main(String args[])
    {
        int a=7;
        int b=72;
        int sum=a+b;
        System.out.println("Sum is:"+sum);
    }
}
