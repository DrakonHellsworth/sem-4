// write a java program to declare two integers and print their sum
public class exe1b
{
    public static void main(String args[])
    {
        int a=7;
        int b=72;
        int sum=a+b;
        System.out.println("Sum is:"+sum);
    }
}
//observations:creates a class named exe1b and prints the sum of two integers using main method and int data type variables a and b