// write a java program to check whether a character is a vowel or consonant
public class exe1k
{
    public static void main(String args[])
    {
        char ch='a';
        if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
            System.out.println("Vowel");
        else
            System.out.println("Consonant");
    }
}
//observations:creates a class named exe1k and checks whether a character is a vowel or consonant using main method and char data type variable ch for the character using if-else statement to determine vowel or consonant status and print the result.