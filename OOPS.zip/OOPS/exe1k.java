// write a java program to check whether a character is a vowel or consonant
public class exe1k
{
    public static void main(String args[])
    {
        char ch='a';
        if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
            System.out.println("Vowel");
        else
            System.out.println("Consonant");
    }
}
