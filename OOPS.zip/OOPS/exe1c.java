// write a java program to calculate the area of a rectangle
public class exe1c
{
    public static void main(String args[])
    {
        int l=17;
        int b=55;
        int area=l*b;
        System.out.println("Area of rectangle is:"+area);
    }
}
//observations:creates a class named exe1c and prints the area of a rectangle using main method and int data type variables l and b for length and breadth respectively 