//create a class with a default constructor that prints a message when an object is created
class exe2_4
{
    exe2_4() 
    {
        System.out.println("Object is created using default constructor");
    }
    public static void main(String args[]) 
    {
        exe2_4 obj=new exe2_4();
    }
}