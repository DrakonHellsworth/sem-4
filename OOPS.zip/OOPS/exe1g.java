// write a java program to check whether a number is even or odd
public class exe1g
{
    public static void main(String args[])
    {
        int n=7;
        if(n%2==0)
            System.out.println("Number is even");
        else
            System.out.println("Number is odd");
    }
}
//observations:creates a class named exe1g and checks whether a number is even or odd using main method and int data type variable n for the number using modulus operator and if-else statement to determine evenness or oddness.