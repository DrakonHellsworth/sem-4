// write a java program to check whether a number is even or odd
public class exe1g
{
    public static void main(String args[])
    {
        int n=7;
        if(n%2==0)
            System.out.println("Number is even");
        else
            System.out.println("Number is odd");
    }
}
